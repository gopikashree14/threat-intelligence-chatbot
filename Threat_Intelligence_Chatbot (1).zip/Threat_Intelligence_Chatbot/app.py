import os, platform, subprocess, shutil
from datetime import datetime, timezone
import requests
from dotenv import load_dotenv
from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient, DESCENDING
from pymongo.errors import PyMongoError

load_dotenv()
app = Flask(__name__)
MONGO_URI = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
DB_NAME = os.getenv('MONGODB_DB', 'threat_intel_db')
PROVIDER = os.getenv('MODEL_PROVIDER', 'ollama').lower()
OLLAMA_URL = os.getenv('OLLAMA_URL', 'http://localhost:11434/api/chat')
OLLAMA_MODEL = os.getenv('OLLAMA_MODEL', 'qwen2.5:3b')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
CISA_KEV_URL = 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json'
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2500)
db = client[DB_NAME]
threats, chats, scans = db['threats'], db['chat_history'], db['scan_results']

DEMO = [
 {'cve':'DEMO-WIN-001','title':'Windows security update workflow (demo)','status':'Active','platforms':['Windows'],'severity':'High','source':'Synthetic teaching example','verified':False,'summary':'Illustrative record only; not a real CVE or confirmed vulnerability.','mitigation':['Check Windows Update and vendor security advisories','Back up important data before maintenance','Apply supported updates and verify restart requirements']},
 {'cve':'DEMO-LINUX-001','title':'Linux package update workflow (demo)','status':'Evolving','platforms':['Linux'],'severity':'Medium','source':'Synthetic teaching example','verified':False,'summary':'Illustrative record only; not a real CVE or confirmed vulnerability.','mitigation':['Identify the distribution and affected package','Review the distribution security advisory','Use the supported package manager to update']},
 {'cve':'DEMO-MAC-001','title':'macOS security maintenance (demo)','status':'Anticipated','platforms':['macOS'],'severity':'Medium','source':'Synthetic teaching example','verified':False,'summary':'Illustrative record only; not a real CVE or confirmed vulnerability.','mitigation':['Review Apple security releases','Keep macOS and supported applications updated','Maintain a current backup']},
 {'cve':'DEMO-AND-001','title':'Android device security maintenance (demo)','status':'Resolved','platforms':['Android'],'severity':'Low','source':'Synthetic teaching example','verified':False,'summary':'Illustrative record only; not a real CVE or confirmed vulnerability.','mitigation':['Check Android security patch level','Install updates from device settings','Remove unsupported applications']},
 {'cve':'DEMO-IOS-001','title':'iOS security maintenance (demo)','status':'Active','platforms':['iOS'],'severity':'Medium','source':'Synthetic teaching example','verified':False,'summary':'Illustrative record only; not a real CVE or confirmed vulnerability.','mitigation':['Review Apple security updates','Install supported iOS updates','Use a device passcode and trusted app sources']},
]

def db_ok():
    try: client.admin.command('ping'); return True
    except Exception: return False

def seed_demo():
    if db_ok() and threats.count_documents({}) == 0:
        for row in DEMO:
            row = dict(row); row['updated_at'] = datetime.now(timezone.utc); threats.insert_one(row)

@app.route('/')
def index():
    seed_demo()
    rows = list(threats.find({}, {'_id':0}).sort('updated_at', DESCENDING).limit(100)) if db_ok() else DEMO
    return render_template('index.html', threats=rows)

@app.get('/api/health')
def health():
    return jsonify({'status':'ok','database':'connected' if db_ok() else 'unavailable','model_provider':PROVIDER,'time':datetime.now(timezone.utc).isoformat()})

@app.get('/api/threats')
def list_threats():
    platform_name=request.args.get('platform'); status=request.args.get('status')
    query={}
    if platform_name and platform_name!='All': query['platforms']=platform_name
    if status and status!='All': query['status']=status
    try:
        data=list(threats.find(query, {'_id':0}).sort('updated_at',DESCENDING).limit(100)) if db_ok() else [x for x in DEMO if (not platform_name or platform_name=='All' or platform_name in x['platforms']) and (not status or status=='All' or status==x['status'])]
        return jsonify(data)
    except PyMongoError as e: return jsonify({'error':'Database query failed','detail':str(e)}),503

def model_answer(message, context):
    system = ('You are a defensive cybersecurity threat-intelligence assistant. Explain clearly for students and administrators. '
      'Use the supplied records as context and clearly label synthetic demo records. Do not claim a host is vulnerable without evidence. '
      'Give defensive mitigation steps, cite source names when present, and state uncertainty. Never execute commands or provide exploit instructions.')
    prompt = f'Threat records (may include synthetic examples): {context}\nUser question: {message}'
    if PROVIDER == 'openai':
        if not OPENAI_API_KEY: return 'Hosted LLM is selected, but OPENAI_API_KEY is missing. Add it to .env and restart the app.\n\nFor now, check the threat records below and follow official vendor advisories.'
        from openai import OpenAI
        response=OpenAI(api_key=OPENAI_API_KEY).chat.completions.create(model=OPENAI_MODEL,messages=[{'role':'system','content':system},{'role':'user','content':prompt}],temperature=0.2)
        return response.choices[0].message.content
    response=requests.post(OLLAMA_URL,json={'model':OLLAMA_MODEL,'messages':[{'role':'system','content':system},{'role':'user','content':prompt}],'stream':False},timeout=90)
    response.raise_for_status(); return response.json()['message']['content']

@app.post('/api/chat')
def chat():
    body=request.get_json(silent=True) or {}; message=(body.get('message') or '').strip(); plat=body.get('platform','All')
    if not message: return jsonify({'error':'Please enter a question.'}),400
    query={} if plat=='All' else {'platforms':plat}
    try: context=list(threats.find(query, {'_id':0}).limit(30)) if db_ok() else [x for x in DEMO if plat=='All' or plat in x['platforms']]
    except Exception: context=[]
    for item in context:
        if isinstance(item.get('updated_at'),datetime): item['updated_at']=item['updated_at'].isoformat()
    try: answer=model_answer(message,context)
    except Exception as e:
        answer=('The AI model could not be reached. Check that Ollama is running and the configured model is downloaded, '
                'or configure a hosted provider in .env.\n\nThis is not a live threat assessment. Review official vendor advisories. Error: '+str(e)[:300])
    if db_ok():
        try: chats.insert_one({'platform':plat,'user_message':message,'assistant_message':answer,'created_at':datetime.now(timezone.utc)})
        except Exception: pass
    return jsonify({'answer':answer,'records_used':len(context),'note':'Demo records are illustrative unless marked verified.'})

@app.post('/api/sync-cisa')
def sync_cisa():
    try:
        response=requests.get(CISA_KEV_URL,timeout=20); response.raise_for_status(); payload=response.json()
        imported=0
        if not db_ok(): return jsonify({'error':'MongoDB is unavailable.'}),503
        for row in payload.get('vulnerabilities',[]):
            doc={'cve':row.get('cveID'),'title':row.get('vulnerabilityName','Untitled vulnerability'),'status':'Active','platforms':['Windows','Linux','macOS','Android','iOS'],'severity':'Unknown','source':'CISA KEV Catalog','verified':True,'summary':row.get('shortDescription',''),'vendorProject':row.get('vendorProject'),'product':row.get('product'),'dateAdded':row.get('dateAdded'),'dueDate':row.get('dueDate'),'requiredAction':row.get('requiredAction'),'sourceUrl':'https://www.cisa.gov/known-exploited-vulnerabilities-catalog','updated_at':datetime.now(timezone.utc)}
            threats.update_one({'cve':doc['cve']},{'$set':doc},upsert=True); imported+=1
        return jsonify({'message':'CISA KEV catalog synchronized. Check vendor/product applicability before acting.','records_processed':imported})
    except Exception as e: return jsonify({'error':'CISA synchronization failed: '+str(e)[:300]}),502

@app.post('/api/scan-summary')
def scan_summary():
    # Read-only inventory summary; intentionally does not perform vulnerability detection or change the host.
    info={'hostname':platform.node(),'os':platform.platform(),'system':platform.system(),'release':platform.release(),'python':platform.python_version(),'package_manager_available':{x:bool(shutil.which(x)) for x in ['winget','apt','dnf','yum','brew']},'scan_type':'read-only host summary, not a vulnerability scan','created_at':datetime.now(timezone.utc).isoformat()}
    if db_ok():
        try: scans.insert_one(dict(info))
        except Exception: pass
    return jsonify(info)

@app.post('/api/remediation-preview')
def remediation_preview():
    body=request.get_json(silent=True) or {}; cve=body.get('cve',''); item=threats.find_one({'cve':cve},{'_id':0}) if db_ok() else next((x for x in DEMO if x['cve']==cve),None)
    if not item: return jsonify({'error':'Threat record not found.'}),404
    return jsonify({'title':item.get('title'),'cve':cve,'steps':item.get('mitigation',[]),'safety':'Preview only. No commands were executed and no system changes were made. Verify the vendor advisory and obtain administrator approval before applying changes.'})

if __name__=='__main__':
    app.run(host='127.0.0.1',port=int(os.getenv('PORT','5000')),debug=False)
