# LLM/SLM-Based Threat Intelligence Chatbot using MongoDB

A Flask web application for exploring threat records for Windows, Linux, macOS, Android and iOS. It includes status/platform filters, chat using Ollama or a hosted OpenAI-compatible provider, MongoDB chat history, optional CISA KEV synchronization, a read-only host summary, and mitigation previews.

## Safety and accuracy
- Seeded `DEMO-*` entries are synthetic examples, not real CVEs. They are marked unverified.
- CISA KEV indicates known exploitation, but does not prove the local machine is affected. Verify vendor, product, version and advisory before acting.
- The host summary is not a complete vulnerability scanner.
- Remediation is preview-only: the app does not run shell commands, install updates, or modify the host.
- This is an educational prototype, not a production security service. Add authentication, authorization, audit logging, rate limiting and deployment hardening before real use.

## Requirements
- Python 3.10+
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- For local AI: Ollama installed and running, with a model downloaded
- OR a hosted model API key

## Run on Windows 11 (PowerShell)
1. Install Python and MongoDB Community Server, or create a MongoDB Atlas database. Ensure the database connection works.
2. Extract this ZIP and open PowerShell in the extracted `Threat_Intelligence_Chatbot` folder.
3. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
4. Install packages:
   ```powershell
   python -m pip install -r requirements.txt
   ```
5. Create your environment file:
   ```powershell
   Copy-Item .env.example .env
   ```
6. Open `.env` and set `MONGODB_URI` to your local MongoDB URI or Atlas connection string. Do not share `.env` or publish API keys.
7. Choose one AI provider:
   - Ollama: install Ollama, then run `ollama pull qwen2.5:3b`. Keep `MODEL_PROVIDER=ollama`.
   - Hosted: set `MODEL_PROVIDER=openai`, add your key to `OPENAI_API_KEY`, and select the permitted model in `OPENAI_MODEL`.
8. Start the application:
   ```powershell
   python app.py
   ```
9. Open `http://127.0.0.1:5000` in your browser.
10. Check `http://127.0.0.1:5000/api/health`. Use MongoDB Compass to inspect `threat_intel_db` collections: `threats`, `chat_history`, and `scan_results`.

## Quick demonstration
1. Filter threat records by platform and lifecycle status.
2. Ask the chatbot a defensive question.
3. Click **Preview mitigation** on a record; this only displays advice.
4. Click **Read-only host summary** to view basic host information.
5. Optionally click **Sync CISA KEV** to import the official catalog into MongoDB. This requires network access and a working MongoDB connection.

## Troubleshooting
- MongoDB unavailable: start the MongoDB Windows service or verify Atlas URI/network access.
- Ollama unavailable: launch Ollama and confirm the model exists with `ollama list`.
- Hosted model error: check API key, model access, billing/quota and network connection.
- Port in use: set a different `PORT` in `.env`.

## Project files
- `app.py` — Flask routes, MongoDB integration, AI model adapters, CISA sync and safe preview endpoints
- `templates/index.html` — web interface
- `static/style.css` — responsive styling
- `static/app.js` — filters, chat and API interactions
- `.env.example` — configuration template
- `requirements.txt` — Python dependencies

## Academic note
This ZIP is a runnable prototype starter. It has not been tested against your own MongoDB installation, model provider or credentials. Run it locally and capture genuine screenshots/output for your submission; do not describe expected output as verified execution.
